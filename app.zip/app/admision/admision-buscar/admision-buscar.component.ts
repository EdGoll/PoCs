import { Component, OnInit } from '@angular/core';
import { AdmisionService } from 'src/app/service/admision.service';
import { Router } from '@angular/router';
import { DataStorageService } from 'src/app/service/data-storage.service';

@Component({
  selector: 'app-admision-buscar',
  templateUrl: './admision-buscar.component.html'
})
export class AdmisionBuscarComponent implements OnInit {

  public patenteInput: string;

  constructor(
    private admisionService: AdmisionService,
    private router: Router,
    private dataStorageService: DataStorageService
    ) {}

  ngOnInit() {
  }

  buscarPatente() {
    this.dataStorageService.data = {
      patenteInput: this.patenteInput
    };
    this.router.navigate(['ultimos/consultas/patente/' + this.patenteInput]);
  }

}
