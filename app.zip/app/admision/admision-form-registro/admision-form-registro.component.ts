import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Pais } from 'src/app/model/pais';
import { PaisService } from 'src/app/service/pais.service';
import { TipoDocumentoService } from 'src/app/service/tipo-documento.service';
import { TipoVehiculoService } from 'src/app/service/tipo-vehiculo.service';
import { AdmisionFormService } from 'src/app/service/admision-form.service';
import { AdmisionForm } from 'src/app/model/admision-form';
import { Vehiculo } from 'src/app/model/vehiculo';
import { Persona } from 'src/app/model/persona';
import { AdmisionService } from '../../service/admision.service';
import { NotificacionService } from 'src/app/common/notificacion.service';
import { Item } from 'src/app/model/item';
import { ValidateFormatoPatente, ValidateFormatoRut } from 'src/app/util/ValidateFormatoPatente';
import { ValidarRut } from 'src/app/util/validar-rut';


@Component({
  selector: 'app-admision-form-registro',
  templateUrl: './admision-form-registro.component.html'
})

export class AdmisionFormRegistroComponent implements OnInit {

  registroAdmision: FormGroup;
  submitted = false;
  titulo = 'Formulario para ingreso manual de vehiculos en frontera';
  public paises: any[];
  public tiposDocs: Item[];
  docConductorSelected: string ='Seleccionar';
  docVehSelected: string ='Seleccionar';
  @ViewChild('fadm') myNgForm;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private paisesService: PaisService,
    private tiposDocsService: TipoDocumentoService,
    private admisionService: AdmisionService,
    private notificationsService: NotificacionService
  ) { }

  ngOnInit() {
    this.registroAdmision = this.fb.group({
        paisVeh: ['', Validators.required],
        placaVeh: ['', [Validators.required]],
        pNombre: ['', [Validators.required, Validators.pattern('^[a-zA-ZÀ-ÖØ-öø-ÿ]+$')]],
        sNombre: ['', [ Validators.pattern('^[a-zA-ZÀ-ÖØ-öø-ÿ]+$')]],
        pApellido: ['', [Validators.required, Validators.pattern('^[a-zA-ZÀ-ÖØ-öø-ÿ]+$')]],
        sApellido: ['', [Validators.required, Validators.pattern('^[a-zA-ZÀ-ÖØ-öø-ÿ]+$')]],
        numDoc: ['', [Validators.required]],
        tipoDocConductorSelected: ['', Validators.required],
        paisConductorSelected: ['', Validators.required],
        cantidadPasajeros: ['', [Validators.required, Validators.pattern('[0-9]*'), Validators.maxLength(3)]]
    }, { validator: [ValidateFormatoPatente(), ValidateFormatoRut()]});
    this.obtenerPaises();
    this.obtenerTiposDocumentos();
   // this.obtenerTiposVehiculos();
  }

get f() { return this.registroAdmision.controls; }

  onSubmit() {

    this.submitted = true;

    if (this.registroAdmision.invalid) {
       return;
    }
    // console.log(this.registroAdmision);
    let veh =  {} as Vehiculo;
    veh.pais = {} as Item;
    veh.pais.id = this.registroAdmision.controls.paisVeh.value;
    veh.placa = this.registroAdmision.controls.placaVeh.value;
  //  veh.tipoVehiculo = {} as Item;
  //  veh.tipoVehiculo.id = this.registroAdmision.controls.tipoVeh.value.id;

    let conductor =  {} as Persona;
    conductor.primerNombre = this.registroAdmision.controls.pNombre.value;
    conductor.segundoNombre = this.registroAdmision.controls.sNombre.value;
    conductor.apPaterno = this.registroAdmision.controls.pApellido.value;
    conductor.apMaterno = this.registroAdmision.controls.sApellido.value;
    conductor.tipoDoctoIdentif = {} as Item;
    conductor.tipoDoctoIdentif.id = this.registroAdmision.controls.tipoDocConductorSelected.value;
    let numDoc: string = this.registroAdmision.controls.numDoc.value;
    let dv: string = null;
    if (this.registroAdmision.controls.paisConductorSelected.value == 997) {
      numDoc = ValidarRut.clean(numDoc);
      conductor.nroDocumentoIdentif = numDoc.substr(0, numDoc.length - 1);
      dv = numDoc.substr(numDoc.length - 1);
      conductor.dv = dv;
    } else {
      conductor.nroDocumentoIdentif = numDoc;
      conductor.dv = dv;
    }
    conductor.nacionalidad = {} as Item;
    conductor.nacionalidad.id = this.registroAdmision.controls.paisConductorSelected.value;

    let admForm =  {} as AdmisionForm;
    admForm.vehiculo = veh;
    admForm.conductor = conductor;
    admForm.cantidadPasajeros = this.registroAdmision.controls.cantidadPasajeros.value;
     console.log(admForm);
    this.admisionService.agregarAdmision(admForm).subscribe(

      response => {
        // console.log(response);
        this.notificationsService.notify('success', 'Solicitud de Admision', 'Guardado Correctamente Evento ' + response);
        this.registroAdmision.reset({paisVeh: '', placaVeh: '', pNombre: '', sNombre: '', pApellido: '',
        sApellido: '', numDoc: '', tipoDocConductorSelected: '', paisConductorSelected: ''});
          },
      error => {
        console.log( error as any);
        this.notificationsService.notify('error', 'Solicitud de Admision', 'Ocurrio un error');
      }
    ); 

     this.volver('/admision');

 }

 

 volver(path: String) {
  this.router.navigate([path]);
}

 obtenerPaises() {
   let paisesFilter: Array<any> = new Array();  
   let paisesAux: Array<any> = new Array();
   const codPaisesArray = [997,224,219,221];
   
   this.paisesService.getTiposPaises().subscribe(
     response => {       
       if (response) {

          paisesFilter.push(
            response.filter( 
                pais =>  codPaisesArray.includes(pais.codigoPais)
            )
          ); 

          paisesAux.push( 
            response.filter( 
                pais =>  !codPaisesArray.includes(pais.codigoPais)
            )
          );  

          this.paises = paisesFilter[0].concat(paisesAux[0]);           
       }
     },
     error => {
       console.log( error as any);
     }
   );
 }

 obtenerTiposDocumentos() {
   this.tiposDocsService.getTiposDocumentos().subscribe(
     response => {
       // console.log(response);
       if (response) {
          this.tiposDocs = response;
       }
     },
     error => {
       console.log( error as any);
     }
   );
 }
/*
 obtenerTiposVehiculos() {
   this.tiposVehService.getTiposVehiculos().subscribe(
     response => {
       console.log(response);
       if (response) {
          this.tiposVehs = response;
       }
     },
     error => {
       console.log( error as any);
     }
   );
 }
*/
 limpiar() {
  this.registroAdmision.reset({paisVeh: '', placaVeh: '', pNombre: '', sNombre: '', pApellido: '',
  sApellido: '', numDoc: '', tipoDocConductorSelected: '', paisConductorSelected: ''});
 }

 onChangeDocConductor(event) {  

  }

 onChangePaisVehiculo(event) {   

  console.log(this.registroAdmision.controls.paisVeh.value);
    if(this.registroAdmision.controls.paisVeh.value == 997){
      console.log('ENTRE->>>>');
      this.registroAdmision.controls.paisConductorSelected.patchValue(997);
      this.registroAdmision.controls.tipoDocConductorSelected.patchValue(this.tiposDocs[4].id);
    }else{
      this.registroAdmision.controls.tipoDocConductorSelected.patchValue(this.tiposDocs[1].id); 
      this.registroAdmision.controls.paisConductorSelected.patchValue(this.registroAdmision.controls.paisVeh.value);
    }

 }

 onChangePaisConductor(event) {   

   if(this.registroAdmision.controls.paisConductorSelected.value == 997){
    this.registroAdmision.controls.tipoDocConductorSelected.patchValue(this.tiposDocs[4].id);
   }else{
    this.registroAdmision.controls.tipoDocConductorSelected.patchValue(this.tiposDocs[1].id);   
   }

 }



}
