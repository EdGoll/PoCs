import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdmisionRoutingModule } from './admision-routing.module';
import { AdmisionAdminComponent } from './admision-admin/admision-admin.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { AdmisionDetalleComponent } from './admision-detalle/admision-detalle.component';
import { AdmisionConsultaComponent } from './admision-consulta/admision-consulta.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AdmisionGridComponent} from './admision-grid/admision-grid.component';
import { AdmisionFormRegistroComponent } from './admision-form-registro/admision-form-registro.component';
import { PanelModule } from 'primeng/panel';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdmisionBuscarComponent } from './admision-buscar/admision-buscar.component';
import { AdmisionDetalleAutComponent} from './admision-detalle/admision-detalle-aut/admision-detalle-aut.component';
import { AdmisionDetalleAlertaComponent } from './admision-detalle/admision-detalle-alerta/admision-detalle-alerta.component';
import { ConfirmationDialogComponent } from '../common/confirmation-dialog/confirmation-dialog.component';
import { InputSwitchModule } from 'primeng/inputswitch';
import {  DropdownModule, ButtonModule } from 'primeng/primeng';

@NgModule({

  declarations: [
    AdmisionAdminComponent,
    AdmisionDetalleComponent,
    AdmisionConsultaComponent,
    AdmisionFormRegistroComponent,
    AdmisionGridComponent,
    AdmisionBuscarComponent,
    AdmisionDetalleAutComponent,
    AdmisionDetalleAlertaComponent
  ],

  imports: [
    CommonModule,
    AdmisionRoutingModule,
    FontAwesomeModule,
    NgbModule,
    TableModule,
    TabViewModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    PanelModule,
    InputSwitchModule,
    DropdownModule,
    ButtonModule
  ], 
  entryComponents: [ConfirmationDialogComponent]

})
export class AdmisionModule { }
