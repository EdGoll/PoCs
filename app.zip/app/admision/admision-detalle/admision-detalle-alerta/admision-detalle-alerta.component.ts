import { Component, OnInit, Input } from '@angular/core';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';

@Component({
  selector: 'app-admision-detalle-alerta',
  templateUrl: './admision-detalle-alerta.component.html',
  styleUrls: ['./admision-detalle-alerta.component.css']
})
export class AdmisionDetalleAlertaComponent implements OnInit {

  @Input()
  admisionInput: EventoIngresoSalida;

  constructor() { }

  ngOnInit() {
  }

}
