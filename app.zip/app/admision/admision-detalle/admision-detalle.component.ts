import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AdmisionService } from 'src/app/service/admision.service';
import { DataStorageService } from 'src/app/service/data-storage.service';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';
import { LoginService } from 'src/app/service/login.service';

@Component({
  selector: 'app-admision-detalle',
  templateUrl: './admision-detalle.component.html'
})
export class AdmisionDetalleComponent implements OnInit {

  public evento: any;
  admision: EventoIngresoSalida = null;
  tipoRevision: string;

  public showObsView = false;
  public showAutView = false;
  public showAlertaView = true; // se deja en true para probar

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private admisionService: AdmisionService,
    private dataStorageService: DataStorageService,
    private loginService: LoginService
  ) {

      if (dataStorageService.data != null) {
        // console.log(dataStorageService.data);
        this.admision = dataStorageService.data.admision;
        this.tipoRevision = dataStorageService.data.tipoRevision;
      } else {
        this.admision = null;
        this.tipoRevision = null;
        this.loginService.logout();
        this.router.navigate(['/']);
      }
      this.evalPanelType(this.admision);
    }

  ngOnInit() {
  }

  volver(path: string) {
    this.router.navigate(['/' + path]);
  }

  evalPanelType(adm: EventoIngresoSalida) {
    // console.log(adm);
    if (adm != null && adm.estadoAutorizacion != null) {
      if (adm.estadoAutorizacion.id === 'OB' ) {
        this.showObsView = true;
      } else if (adm.estadoAutorizacion.id === 'AM'
              || adm.estadoAutorizacion.id === 'AS' ) {
        this.showAutView = true;
      } else if (adm.estadoAutorizacion.id === 'PA' ) {
        this.showAutView = true;
      }
    }
  }

}
