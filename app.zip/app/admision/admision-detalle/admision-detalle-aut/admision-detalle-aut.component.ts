import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AdmisionService } from 'src/app/service/admision.service';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';
import { UtilVeh } from 'src/app/common/util-veh';
import { NotificacionService } from 'src/app/common/notificacion.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationDialogService } from 'src/app/common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-admision-detalle-aut',
  templateUrl: './admision-detalle-aut.component.html'
})
export class AdmisionDetalleAutComponent implements OnInit {


public evento: any;
@Input()
admisionInput: EventoIngresoSalida;
@Input()
tipoRevision: string;

justificacion: string;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private admisionService: AdmisionService,
    private notificationsService: NotificacionService,
    private confirmationDialogService: ConfirmationDialogService) {
     }

  ngOnInit() {
    // console.log(this.tipoRevision);
  }

  actionVolver() {
    this.volver('admision');
  }

  private volver(path: string) {
    this.router.navigate(['/' + path]);
  }

  habilitarBotonEvento(evento: EventoIngresoSalida, botonAccion: string): boolean {
    return UtilVeh.habilitarBotonEvento(evento, botonAccion);
  }

  confirmarAccion(accion: string) {

    this.confirmationDialogService.confirm('SICVE', UtilVeh.getMensajeConfirmacion(accion))
    .then(
      (confirmed) => {
        if (confirmed) {
          if (accion === 'APROBAR') {
            this.actionAprobar();
          } else if (accion === 'REC') {
            this.actionRechazar();
          } else if (accion === 'SEC') {
            this.actionInspeccionSecundaria();
          } else if (accion === 'EXH') {
            this.enviarExhaustiva();
          } else if (accion === 'DERIVAR') {
            this.derivarInspeccion();
          }
          this.actionVolver();
          console.log('User confirmed:', confirmed);
        } else {
          console.log('User cancel:', confirmed);
        }
    }
    )
    .catch(() => console.log('El usuario descarto el dialog, es decir hizo clic en ESC o clickeo fuera del dialogo)'));

}

  actionAprobar() {
    // this.admisionService.aprobarAdmision(this.admision);
    // console.log(this.admisionInput);
    this.admisionService.accionEventoAdmision(this.admisionInput, 'APROBAR', null).subscribe(
      resp => {
        // console.log(resp);
        this.notificationsService.notify('success', 'Proceso de Aprobación', 'Se ha realizado correctamente');
        this.actionVolver();
      }, error => {
        console.log(error);
        this.notificationsService.notify('error', 'Proceso de Aprobación', 'Ocurrio un error');
      }
    );
  }

  actionInspeccionSecundaria() {
    // this.admisionService.inspecionarAdmision(this.admision, this.justificacion);
    this.admisionService.accionEventoAdmision(this.admisionInput, 'SEC', this.justificacion).subscribe(
      resp => {
        // console.log(resp);
        this.notificationsService.notify('success', 'Proceso de Inspección', 'Se ha realizado correctamente');
        this.actionVolver();
      }, error => {
        console.log(error);
        this.notificationsService.notify('error', 'Proceso de Inspección', 'Ocurrio un error');
      }
    );
  }

  actionRechazar() {
    // this.admisionService.rechazarAdmision(this.admision, this.justificacion);
    this.admisionService.accionEventoAdmision(this.admisionInput, 'REC', this.justificacion).subscribe(
      resp => {
        // console.log(resp);
        this.notificationsService.notify('success', 'Proceso de Rechazo', 'Se ha realizado correctamente');
        this.actionVolver();
      }, error => {
        console.log(error);
        this.notificationsService.notify('error', 'Proceso de Rechazo', 'Ocurrio un error');
      }
    );
  }

  enviarExhaustiva(){
    this.admisionService.accionEventoAdmision(this.admisionInput, 'EXH', null).subscribe(
      resp => {
        // console.log(resp);
        this.actionVolver();
      }, error => {
        console.log(error);
      }
    );
  }

  derivarInspeccion() {
    this.admisionService.accionEventoAdmision(this.admisionInput, 'DERIVAR', null).subscribe(
      resp => {
        // console.log(resp);
        this.actionVolver();
        this.notificationsService.notify('success', 'La autorizacion se ha derivado.', 'Se ha realizado correctamente');        
      }, error => {
        console.log(error);
      }
    );
  }

}
