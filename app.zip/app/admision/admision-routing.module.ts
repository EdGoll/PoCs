import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdmisionAdminComponent } from './admision-admin/admision-admin.component';
import { AdmisionDetalleComponent } from './admision-detalle/admision-detalle.component';
import { AdmisionConsultaComponent } from './admision-consulta/admision-consulta.component';
import { AdmisionFormRegistroComponent } from './admision-form-registro/admision-form-registro.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/admision2',
    pathMatch: 'full'
  },
  {
    path: 'admision',
    component: AdmisionAdminComponent,
    data:{
        authorities: [],
        pageTitle: 'Titulo del Administrador de admision'
    },
  },
  {
    path: 'ultimos/admision/sid/:id',
    component: AdmisionDetalleComponent
  },
  {
    path: 'ultimos/consultas/patente/:patenteInput',
    component: AdmisionConsultaComponent
  },
  {
    path: 'admision/registro',
    component: AdmisionFormRegistroComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdmisionRoutingModule { }
