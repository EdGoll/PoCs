import { Component, OnInit } from '@angular/core';
import { AdmisionService } from '../../service/admision.service';
import { Router, NavigationExtras, ActivatedRoute, Params } from '@angular/router';
import { DataStorageService } from '../../service/data-storage.service';
import { Observable } from 'rxjs/internal/Observable';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';


@Component({
  selector: 'app-admision-consulta',
  templateUrl: './admision-consulta.component.html',
  providers: [AdmisionService]
})
export class AdmisionConsultaComponent implements OnInit {

  admisiones: EventoIngresoSalida[];
  public evento: any;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private admisionService: AdmisionService,
    private dataStorageService: DataStorageService
  ) {
  }

  ngOnInit() {
    this.buscarEventoPorPatente();
  }

buscarEventoPorPatente() {
  this.route.params.forEach((params: Params) => {
    const patenteInput = params['patenteInput'];
    this.admisionService.getEventoPorPatente(patenteInput).subscribe(
        response => {
            console.log(response);
            if (response) {
              this.admisiones=response;
            }
          },
          error => {
            console.log(<any>error);
          }
         );
  });
  }

  irADetalleAdmision(item: EventoIngresoSalida) {

    this.dataStorageService.data = {
      admision: item
    }
    this.router.navigate(['ultimos/admision/sid/' + item.idEvento]);
  }

}
