import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { VERSION } from 'src/app/app.constants';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginService } from '../../service/login.service';
import { LoginComponent } from 'src/app/usuario/login/login.component';
import { PuntoControl } from 'src/app/model/punto-control';
import { SessionStorageService } from 'ngx-webstorage';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  providers: [LoginService]
})
export class NavbarComponent implements OnInit {

  inProduction: boolean;
  isNavbarCollapsed: boolean;
  languages: any[];
  swaggerEnabled: boolean;
  modalRef: NgbModalRef;
  version: string;
  private isOpen = false;
  // variable temporal
  private authenticated = false;
  puntoControl: PuntoControl;

  constructor(
     private loginService: LoginService,
     private sessionStorage: SessionStorageService,
    // private accountService: AccountService
    // private profileService: ProfileService,
     private modalService: NgbModal,
     private router: Router
) {
    this.version = VERSION ? 'v' + VERSION : '';
    this.isNavbarCollapsed = true;
}

  ngOnInit() {
  }

  changeLanguage(languageKey: string) {
   // this.sessionStorage.store('locale', languageKey);
   // this.languageService.changeLanguage(languageKey);
}

collapseNavbar() {
  //  console.log('entro a colapse navbar');
    this.isNavbarCollapsed = true;
}

isAuthenticated() {
    return this.loginService.isAuthenticated();
}

isAsignadoPuntoControl(){
  this.puntoControl = JSON.parse(this.sessionStorage.retrieve('puntoControl'));
  if (this.puntoControl == null) {
    return false;
  }
  return true;
}

login() {
  // console.log('antes de abrir popup');
  this.modalRef = this.openPopupLogin();
  // console.log('despues de abrir ');
}

openPopupLogin(): NgbModalRef {
  if (this.isOpen) {
    return;
  }
  this.isOpen = true;
  const modalRef = this.modalService.open(LoginComponent);
  modalRef.result.then(
    result => {
      this.isOpen = false;
    },
    reason => {
      this.isOpen = false;
    }
  );
  return modalRef;
}

logout() {

  this.loginService.logout();
  this.limpiarVariables();
  $('.navbar-toggler').click();
  this.router.navigate(['']);
}

toggleNavbar() {
  // console.log('entro a toggleNavbar');
  this.isNavbarCollapsed = !this.isNavbarCollapsed;
  // console.log(this.isNavbarCollapsed);
}

getImageUrl() {
   // return this.isAuthenticated() ? this.accountService.getImageUrl() : null;
   return null;
}

navegarA(path) {
  $('.navbar-toggler').click();
  this.router.navigate(['/' + path]);
}

limpiarVariables(): void {
  this.puntoControl = null;
}

}
