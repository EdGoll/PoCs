import { Component, OnInit } from '@angular/core';
import $ from 'jquery';
import { Subscription } from 'rxjs';
import { SocketStompProvider } from 'src/app/service/socket/socket-stomp-provider.service';
import { Message } from '@stomp/stompjs';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';

@Component({
  selector: 'app-salida-prueba',
  templateUrl: './salida-prueba.component.html',
  styleUrls: ['./salida-prueba.component.css']
})
export class SalidaPruebaComponent implements OnInit {

  private serverUrl = '/veh-api/live';
  public title = 'WebSockets chat';
  private stompClient;
  public salidas: EventoIngresoSalida[];
  private topicSubscription: Subscription;

  constructor(private socketService: SocketStompProvider) {

    this.socketService.suscribir('/topic/message').subscribe(
      (message: Message) => {
        console.log(message.body);
      }
    );
   }

  ngOnInit() {
  }

  sendMessage(message){
    this.stompClient.send('/app/send/message' , {}, message);
    $('#input').val('');
  }

}
