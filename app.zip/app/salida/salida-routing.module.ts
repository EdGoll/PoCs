import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SalidaAdminComponent } from './salida-admin/salida-admin.component';
import { SolicitudSalidaComponent } from './solicitud-salida/solicitud-salida.component';
import { SalidaProcesadaComponent } from './salida-procesada/salida-procesada.component';
import { SalidaDetallePrincipalComponent } from './salida-detalle-principal/salida-detalle-principal.component';
import { SalidaPruebaComponent } from './salida-prueba/salida-prueba.component';
import { AccesoRutasUsuarioService } from '../service/acceso-rutas-usuario.service';

const routes: Routes = [
  { path: '', redirectTo: '/salida', pathMatch: 'full'},
  {
    path: 'salida',
    component: SalidaAdminComponent,
    data: {
        authorities: [],
        pageTitle: 'Titulo del Administrador de salida'
    },
    children: [
      { path: '', redirectTo: '/salida/solicitudSalida', pathMatch: 'full'},
      { path: 'solicitudSalida', component: SolicitudSalidaComponent},
      { path: 'salidaProcesada', component: SalidaProcesadaComponent},
      {
        path: 'salida-detalle/:id', component: SalidaDetallePrincipalComponent,
        data: {
          authorities: ['ROLE_ADMIN', 'ROLE_USER']
        },
        canActivate: [AccesoRutasUsuarioService]
      },
      { path: 'salidaprueba', component: SalidaPruebaComponent}
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalidaRoutingModule { }
