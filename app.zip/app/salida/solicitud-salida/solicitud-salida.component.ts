import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { SalidaService } from 'src/app/service/salida.service';
import { DataStorageService } from 'src/app/service/data-storage.service';
import { Router } from '@angular/router';
import { DataTable } from 'primeng/primeng';
import { Observable, BehaviorSubject, interval, Subscription } from 'rxjs';
import { PuntoControl } from 'src/app/model/punto-control';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';
import { UtilVeh } from 'src/app/common/util-veh';
import { ConfirmationDialogService } from 'src/app/common/confirmation-dialog/confirmation-dialog.service';
import { NotificacionService } from 'src/app/common/notificacion.service';
import { SessionStorageService } from 'ngx-webstorage';
import { switchMap, startWith, map } from 'rxjs/operators';

@Component({
  selector: 'app-solicitud-salida',
  templateUrl: './solicitud-salida.component.html',
  styleUrls: ['./solicitud-salida.component.css'],
  providers: []
})
export class SolicitudSalidaComponent implements OnInit, OnDestroy {

  public salidas: EventoIngresoSalida[];
  @ViewChild(('dt')) dt: DataTable;

  salidas$: Observable<EventoIngresoSalida[]>;
  singleSalida$: Observable<EventoIngresoSalida>;
  checkeado = true;
  interval$: BehaviorSubject<number> = new BehaviorSubject<number>(30000);
  private subscription: Subscription;

  constructor(private salidaService: SalidaService,
              private dataStorageService: DataStorageService,
              private router: Router,
              private confirmationDialogService: ConfirmationDialogService,
              private notificationsService: NotificacionService,
              private sessionStorage: SessionStorageService) {

                // console.log('constructor salidas:');
   }

  ngOnInit() {
    this.salidas$ = this.salidaService.salidas;

    const puntoControl = this.sessionStorage.retrieve('puntoControl') ;
    const idPuntoControl = (JSON.parse(puntoControl) as PuntoControl).codPunto;
    const idAduana = (JSON.parse(puntoControl) as PuntoControl).codAduana;
    this.salidaService.getSolicitudesSalida(idPuntoControl, idAduana);
    // this.salidaService2.openWebSocketSolicitudesSalida();
    this.subscription = this.cargarAutomaticamenteGrilla().subscribe( resp => {
      if(this.checkeado){
        console.log('llamando periodicamente');
        this.salidaService.getSolicitudesSalida(idPuntoControl, idAduana);
      }
    }, error => {
      this.setInterval(100000000000);
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /**
   * Metodo que pinta las filas segun el estado del evento
   * @param idEstado estado proveniente de evento ingreso salida
   */
  pintarFilaSegunEstado(evento: EventoIngresoSalida): string{
    return UtilVeh.pintarFilaSegunEstado(evento);
  }

  /**
   *
   * @param evento Metodo que se encarga de habilitar el boton segun el tipo evento,estado de autorizacion y estado atencion
   * @param botonAccion
   */
  habilitarBotonEvento(evento: EventoIngresoSalida, botonAccion: string): boolean {
    return UtilVeh.habilitarBotonEvento(evento, botonAccion);
  }

  /**
   * Metodo que se encarga de redirigir a la pagina de detalle del evento
   * @param item Objeto salida correspondiente al evento de ingreso salida
   */
  irADetalleSalida(item: EventoIngresoSalida) {

    this.dataStorageService.data = {
      salida: item
    };
    this.router.navigate(['/salida/salida-detalle/' + item.idEvento]);
  }

  /**
   * Metodo encargado de filtrar la grilla de solicitudes de salida
   * @param valor Campo de entrada a filtrar
   * @param tipoFiltro criterio de filtrado
   */
  filtrarColumnas(valor, tipoFiltro) {
    this.dt.filter(valor, 'global', tipoFiltro);

  }

  confirmarAutorizarSalida(evento: EventoIngresoSalida){
    this.confirmationDialogService.confirm('SICVE', '¿Confirma autorizar evento ?')
    .then(
      (confirmed) => {
        if (confirmed) {
          this.autorizarSolicitud(evento);
          console.log('User confirmed:', confirmed);
        } else {
          console.log('User cancel:', confirmed);
        }
    }
    )
    .catch(() => console.log('El usuario descarto el dialog, es decir hizo clic en ESC o clickeo fuera del dialogo)'));
  }

  autorizarSolicitud(sal: EventoIngresoSalida) {
    console.log(sal);
    this.salidaService.accionEventoSalida(sal, 'AUTORIZAR', null).subscribe(
        resp => {
          console.log('autorizar exito' + resp);
          this.notificationsService.notify('success', 'Solicitud de Salida', 'Evento Autorizado');
          // this.router.navigate(['/salida/solicitudSalida']);
        },
        error => {
          console.log('Error autorizar:' + error);
        }
      );
  }

  setInterval(newInterval: number){
    this.interval$.next(newInterval);
  }

  cargarAutomaticamenteGrilla(){
    return this.interval$.pipe(
      switchMap((periodo: number) => interval(periodo)), startWith(0)
    );
  }
}
