import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataStorageService } from 'src/app/service/data-storage.service';
import { SalidaService } from 'src/app/service/salida.service';
import { Location } from '@angular/common';
import { NotificacionService } from 'src/app/common/notificacion.service';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';
import { Observacion } from 'src/app/model/observacion';
import { ConfirmationDialogService } from 'src/app/common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-salida-detalle-principal',
  templateUrl: './salida-detalle-principal.component.html',
  styleUrls: ['./salida-detalle-principal.component.css']
})
export class SalidaDetallePrincipalComponent implements OnInit {

  salida: EventoIngresoSalida = null;
  public observacionEvento;
  observacionList: Observacion[];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dataStorageService: DataStorageService,
    private salidaService: SalidaService,
    private location: Location,
    private notificationsService: NotificacionService,
    private confirmationDialogService: ConfirmationDialogService
  ) {
    if (dataStorageService.data != null) {
      // console.log(dataStorageService.data);
      this.salida = dataStorageService.data.salida;
      // this.salida = JSON.parse(dataStorageService.data);
      // dataStorageService.data = null;
    } else {
      this.salida = null;
    }

    let id = this.route.snapshot.paramMap.get('id');
    if (id != null && id !== undefined) {
    this.salidaService.getEvento(id).subscribe(
      resp => {
        this.salida = resp; /*
        if (this.salida != null && this.salida.idEvento != null) {
          this.obtenerObservacionIngresoSalida(this.salida.idEvento);
        }*/
      },
      error => {
        console.log(error);
      }
    );
    }
  }

  ngOnInit() {
  }

  confirmarAutorizarSolicitud(sal: EventoIngresoSalida) {
    this.confirmationDialogService.confirm('SICVE', '¿Confirma autorizar evento ?')
    .then(
      (confirmed) => {
        if (confirmed) {
          this.autorizarSolicitud(sal);
          console.log('User confirmed:', confirmed);
        } else {
          console.log('User cancel:', confirmed);
        }
    }
    )
    .catch(() => console.log('El usuario descarto el dialog, es decir hizo clic en ESC o clickeo fuera del dialogo)'));
  }

  autorizarSolicitud(sal: EventoIngresoSalida) {
    console.log(sal);
    this.salidaService.accionEventoSalida(sal, 'AUTORIZAR', null).subscribe(
        resp => {
          // console.log('autorizar exito' + resp);
          this.notificationsService.notify('success', 'Solicitud de Salida', 'Evento Autorizado');
          this.router.navigate(['/salida/solicitudSalida']);
        },
        error => {
          console.log('Error autorizar:' + error);
        }
      );
  }

  confirmarRechazarSolicitud(sal: EventoIngresoSalida){
    this.confirmationDialogService.confirm('SICVE', '¿Confirma rechazar evento ?')
    .then(
      (confirmed) => {
        if (confirmed) {
          this.rechazarSolicitud(sal);
          console.log('User confirmed:', confirmed);
        } else {
          console.log('User cancel:', confirmed);
        }
    }
    )
    .catch(() => console.log('El usuario descarto el dialog, es decir hizo clic en ESC o clickeo fuera del dialogo)'));
  }

  rechazarSolicitud(sal: EventoIngresoSalida) {
    // console.log(sal);
    if (this.observacionEvento) {
      // console.log(this.observacionEvento);
      // this.salidaService.guardarEventoRechazado(sal.idEvento, parametros).subscribe(
      this.salidaService.accionEventoSalida(sal, 'RECHAZAR', this.observacionEvento).subscribe(
        resp => {
          console.log('rechazado con exito' + resp);
          this.notificationsService.notify('success', 'Solicitud de Salida', 'Evento Rechazado');
          this.router.navigate(['/salida/solicitudSalida']);

        },
        error => {
          console.log('Error al rechazar:' + error);
        }
      )
    } else {
      console.log('debe ingresar observacion');
    }
  }

  obtenerObservacionIngresoSalida(idEvento) {
    this.salidaService.getListadoEventoObservacion(idEvento).subscribe(
      resp => {
        console.log(resp);
        this.observacionList = resp;
      },
      error => {
        console.log(error);
        this.observacionList = [];
      }
    );
  }

  volver() {
    this.location.back();
  }

  openConfirmationDialog(salida) {
    this.confirmationDialogService.confirm('SICVE', '¿Confirma accion requerida ?')
    .then(
      (confirmed) => {
        if (confirmed) {
          this.autorizarSolicitud(salida);
          console.log('User confirmed:', confirmed);
        } else {
          console.log('User cancel:', confirmed);
        }
    }
    )
    .catch(() => console.log('El usuario descarto el dialog, es decir hizo clic en ESC o clickeo fuera del dialogo)'));
  }
}
