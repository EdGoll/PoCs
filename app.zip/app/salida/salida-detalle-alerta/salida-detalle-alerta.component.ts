import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-salida-detalle-alerta',
  templateUrl: './salida-detalle-alerta.component.html',
  styleUrls: ['./salida-detalle-alerta.component.css']
})
export class SalidaDetalleAlertaComponent implements OnInit {
  @Input() idEvento;

  constructor() {
    this.idEvento = 0;
  }

  ngOnInit() {}
}
