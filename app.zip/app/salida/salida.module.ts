import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalidaRoutingModule } from './salida-routing.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdmisionService } from '../service/admision.service';
import {TableModule} from 'primeng/table';
import {TabViewModule} from 'primeng/tabview';
import {InputTextareaModule} from 'primeng/inputtextarea';
import { FormsModule } from '@angular/forms';
import { SalidaAdminComponent } from './salida-admin/salida-admin.component';
import { SalidaDetalleAlertaComponent } from './salida-detalle-alerta/salida-detalle-alerta.component';
import { SalidaDetalleObservacionComponent } from './salida-detalle-observacion/salida-detalle-observacion.component';
import { SalidaDetallePrincipalComponent } from './salida-detalle-principal/salida-detalle-principal.component';
import { SalidaProcesadaComponent } from './salida-procesada/salida-procesada.component';
import { SalidaPruebaComponent } from './salida-prueba/salida-prueba.component';
import { SolicitudSalidaComponent } from './solicitud-salida/solicitud-salida.component';
import { RxStompService, rxStompServiceFactory, InjectableRxStompConfig } from '@stomp/ng2-stompjs';
import { socketConfig } from '../service/socket/socket-config';
import { ComunModule } from '../common/comun.module';
import { ConfirmationDialogComponent } from '../common/confirmation-dialog/confirmation-dialog.component';
import {InputSwitchModule} from 'primeng/inputswitch';

@NgModule({
  declarations: [
    SalidaAdminComponent,
    SalidaDetalleAlertaComponent,
    SalidaDetalleObservacionComponent,
    SalidaDetallePrincipalComponent,
    SalidaProcesadaComponent,
    SalidaPruebaComponent,
    SolicitudSalidaComponent
  ],
  imports: [
    CommonModule,
    SalidaRoutingModule,
    TableModule,
    TabViewModule,
    FontAwesomeModule,
    NgbModule,
    InputTextareaModule,
    FormsModule,
    ComunModule,
    InputSwitchModule
  ],
  providers: [
    {
      provide: InjectableRxStompConfig,
      useValue: socketConfig
    },
    {
      provide: RxStompService,
      useFactory: rxStompServiceFactory,
      deps: [InjectableRxStompConfig]
    }
  ],
  entryComponents: [ConfirmationDialogComponent]
})
export class SalidaModule { }
