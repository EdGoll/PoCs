import { Component, OnInit, Input } from '@angular/core';
import { SalidaService } from 'src/app/service/salida.service';
import { HistorialAtencion } from 'src/app/model/historial-atencion';
import { Observacion } from 'src/app/model/observacion';

@Component({
  selector: 'app-salida-detalle-observacion',
  templateUrl: './salida-detalle-observacion.component.html',
  styleUrls: ['./salida-detalle-observacion.component.css']
})
export class SalidaDetalleObservacionComponent implements OnInit {

  @Input() idEvento;
  observacionList: Observacion[];
  public observacionEvento;
  constructor(private salidaService: SalidaService) {



  }

  ngOnInit() {
    this.salidaService.getObservacionIngresoSalida(this.idEvento).subscribe(
      resp => {
        // console.log(resp);
        this.observacionList = resp;
      },
      error => {
        console.log(error);
        this.observacionList = [];
      }
    );
  }

}
