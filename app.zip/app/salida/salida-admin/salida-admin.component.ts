import { Component, OnInit } from '@angular/core';
import { SalidaService } from 'src/app/service/salida.service';
import { Router, NavigationExtras } from '@angular/router';
import { DataStorageService } from 'src/app/service/data-storage.service';
import { UsuarioService } from 'src/app/service/usuario.service';
import { LoginService } from 'src/app/service/login.service';
import { NotificacionService } from 'src/app/common/notificacion.service';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';

@Component({
  selector: 'app-salida-admin',
  templateUrl: './salida-admin.component.html',
  styleUrls: ['./salida-admin.component.css']
})
export class SalidaAdminComponent implements OnInit {

  public salidas: EventoIngresoSalida[];

  constructor(private salidaService: SalidaService,
              private router: Router,
              private dataStorageService: DataStorageService,
              private loginService: LoginService,
              private usuarioService: UsuarioService,
              private notificationsService: NotificacionService
    ) { }

  ngOnInit() {
  }
}
