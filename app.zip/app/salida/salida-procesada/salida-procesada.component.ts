import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { SalidaService } from 'src/app/service/salida.service';
import { Router, NavigationExtras } from '@angular/router';
import { DataStorageService } from 'src/app/service/data-storage.service';
import { DataTable } from 'primeng/primeng';
import { Observable, of, BehaviorSubject, Subscription, interval } from 'rxjs';
import { PuntoControl } from 'src/app/model/punto-control';
import { EventoIngresoSalida } from 'src/app/model/evento-ingreso-salida';
import { UtilVeh } from 'src/app/common/util-veh';
import { SessionStorageService } from 'ngx-webstorage';
import { switchMap, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-salida-procesada',
  templateUrl: './salida-procesada.component.html',
  styleUrls: ['./salida-procesada.component.css']
})
export class SalidaProcesadaComponent implements OnInit, OnDestroy {

  public salidas: EventoIngresoSalida[];
  salidas$: Observable<EventoIngresoSalida[]>;
  @ViewChild(('dt')) dt: DataTable;
  checkeado = true;
  interval$: BehaviorSubject<number> = new BehaviorSubject<number>(30000);
  private subscription: Subscription;

  constructor(private salidaService: SalidaService,
              private router: Router,
              private dataStorageService: DataStorageService,
              private sessionStorage: SessionStorageService
    ) { }

  ngOnInit() {
    // llamada rest carga inicial usa el servicio salidaservice
    this.salidas$ = this.salidaService.procesadas;
    this.obtenerAdmisiones();
    this.subscription = this.cargarAutomaticamenteGrilla().subscribe( resp => {
      if(this.checkeado){
        console.log('llamando periodicamente eventos procesados');
        this.obtenerAdmisiones();
      }
    }, error => {
      this.setInterval(100000000000);
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  /**
   * Metodo que obtiene las salidas procesadas
   */
  obtenerAdmisiones() {

  const puntoControl = this.sessionStorage.retrieve('puntoControl') ;
  if(puntoControl) {
    const idPuntoControl = (<PuntoControl>JSON.parse(puntoControl)).codPunto;
    const idAduana = (<PuntoControl>JSON.parse(puntoControl)).codAduana;
    this.salidaService.getProcesadosSalida(idPuntoControl, idAduana);
  }
  }
  /**
   * Metodo que redirige al detalle del evento
   * @param item
   */
  irADetallesalida(item: EventoIngresoSalida) {

    this.dataStorageService.data = {
      salida: item
    };
    this.router.navigate(['/salida/salida-detalle/' + item.idEvento]);
  }

  /**
   * Metodo que pinta las filas segun el estado del evento de salida
   * @param idEstado Estado del evento de salida
   */
  pintarFilaSegunEstado(evento: EventoIngresoSalida): string{
    return UtilVeh.pintarFilaSegunEstado(evento);
  }

  /**
   * Metodo encargado de filtrar la grilla de salidas procesadas
   * @param valor dato a filtrar
   * @param tipoFiltro criterio de filtro
   */
  filtrarColumnas(valor, tipoFiltro) {
    this.dt.filter(valor, 'global', tipoFiltro);
  }

  /**
   * Metodo encargado de cerrar una conexion web socket
   */
  cerrarConexion() {
    // this.salidaService2.desinscribirFlujoSalidasProcesadas();
  }

  /**
   * Metodo encargado de abrir una conexion web socket
   */
  abrirConexion() {
    // this.salidaService2.openWebSocketSalidasProcesadas();
  }

  setInterval(newInterval: number){
    this.interval$.next(newInterval);
  }

  cargarAutomaticamenteGrilla(){
    return this.interval$.pipe(
      switchMap((periodo: number) => interval(periodo)), startWith(0)
    );
  }

}
