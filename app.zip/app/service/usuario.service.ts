import { Injectable } from '@angular/core';
import { Observable, Subject, of } from 'rxjs';
import { HttpHeaders, HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { GLOBAL } from './global';
import { SessionStorageService } from 'ngx-webstorage';
import { Account} from '../model/account';
import { map } from 'rxjs/operators';
import { SecurityVeh } from '../model/security-veh';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private url = null;
  // datos de identity
  private userIdentity: any;
  private authenticated = false;
  private authenticationState = new Subject<any>();


  constructor(private http: HttpClient, private $sessionStorage: SessionStorageService, private securityVeh: SecurityVeh) {
    console.log('Se inicializa servicio usuario');
    this.url = GLOBAL.url;
  }

  authenticate(identity) {
    this.userIdentity = identity;
    this.authenticated = identity !== null;
    this.authenticationState.next(this.userIdentity);
  }

  getUsuarios(): Observable<any> {
/*
    const headers = {
      Authorization: 'Basic ' + btoa('my-trusted-client:secret'),
      'Content-type': 'application/x-www-form-urlencoded'
    };
*/
    const params = new HttpParams()
      .set('access_token', this.$sessionStorage.retrieve('access_token'));

    httpOptions.headers =
    httpOptions.headers.set('Authorization', 'Bearer ' + btoa('my-trusted-client:secret'));
    httpOptions.headers.set('Content-type', 'application/x-www-form-urlencoded');


    return this.http.get(this.url + '/user/', { params});
  }

  /**
   * Obtiene informacion del usuario y sus roles
   */
  fetch(username: string): Observable<HttpResponse<Account>> {
    return this.http.get<Account>(this.url + '/user/account/' + username ,
    { observe: 'response', params: this.securityVeh.getParametrosSeguridad() });
  }

  identity(username: string, force?: boolean): Promise<any> {
    if (force) {
        this.userIdentity = undefined;
    }

    // check and see if we have retrieved the userIdentity data from the server.
    // if we have, reuse it by immediately resolving
    if (this.userIdentity) {
        console.log('Si existe userIdentity');
        return Promise.resolve(this.userIdentity);
    }

    return this.fetch(username)
            .toPromise()
            .then(response => {
                const account = response.body;
                if (account) {
                    this.userIdentity = account;
                    this.authenticated = true;
                    this.$sessionStorage.store('identity', this.userIdentity);
                    this.$sessionStorage.store('authenticated', true);
                    // After retrieve the account info, the language will be changed to
                    // the user's preferred language configured in the account setting
                    //const langKey = this.sessionStorage.retrieve('locale') || this.userIdentity.langKey;
                    //this.languageService.changeLanguage(langKey);
                } else {
                    this.userIdentity = null;
                    this.authenticated = false;
                }
                this.authenticationState.next(this.userIdentity);
                return this.userIdentity;
            })
            .catch(err => {
                this.userIdentity = null;
                this.authenticated = false;
                this.authenticationState.next(this.userIdentity);
                return null;
            });
  }

  hasAnyAuthority(authorities: string[]): boolean {

    if(!this.userIdentity) {
      this.userIdentity = this.$sessionStorage.retrieve('identity');
    }
    /*
    if(!this.authenticated) {
      this.authenticated = this.$sessionStorage.retrieve('authenticated');
    }
*/
  //  if (!this.authenticated || !this.userIdentity || !this.userIdentity.authorities) {
    if (!this.userIdentity || !this.userIdentity.authorities) {
        return false;
    }

    for (let i = 0; i < authorities.length; i++) {
        if (this.userIdentity.authorities.includes(authorities[i])) {
            return true;
        }
    }

    return false;
  }

  isAuthenticated(): boolean {
    return this.authenticated;
  }

  isIdentityResolved(): boolean {
    return this.userIdentity !== undefined;
  }

  getAuthenticationState(): Observable<any> {
    return this.authenticationState.asObservable();
  }

  logoutInterno(): Observable<any> {
    return new Observable(observer => {
        this.$sessionStorage.clear('authenticationToken');
        observer.complete();
    });
  }

  logout() {
    this.logoutInterno().subscribe();
    this.authenticate(null);
  }
}
