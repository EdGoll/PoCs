import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { GLOBAL } from './global';

@Injectable({
  providedIn: 'root'
})
export class TipoVehiculoService {

  public url: string;

  constructor(private http: HttpClient) {
    this.url = GLOBAL.url;
    console.log('Se inicializa servicio TipoVehiculoService');
  }

  getTiposVehiculos(){
    const httpOptionsInner = {
      headers: new HttpHeaders({'Content-Type':  'application/json'})
     };
    return this.http.get<any>(this.url + '/tipos/vehiculos');
  }
}
