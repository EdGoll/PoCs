import { Injectable } from '@angular/core';
import { StompConfig, RxStompService} from '@stomp/ng2-stompjs';
import { IMessage, IPublishParams} from '@stomp/stompjs';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { RxStompState } from '@stomp/rx-stomp';

@Injectable({
  providedIn: 'root'
})
export class SocketStompProvider {
  public stompConfig: StompConfig;
  public stompEndpoint = 'endpointName';
  public stompStatus: string;
  public stompStatusId: number;
  public messages: Observable<any>;
  private readonly showStompStatusId: boolean;
  private readonly debugService: boolean = true;

  constructor(private stompService: RxStompService) {

     // this.debugService = (ENV.LOG_LEVEL !== '0');
      if (this.debugService) {
          this.stateStompService();
      }
  }

  public stateStompService() {
      this.stompService.connectionState$
          .pipe(map((state: number) => RxStompState[state]))
          .subscribe((status: string) => {
              this.stompStatus = status;
              if (this.showStompStatusId) {
                  switch (status) {
                      case 'CONNECTING': {
                          this.stompStatusId = 0;
                          break;
                      }
                      case 'OPEN': {
                          this.stompStatusId = 1;
                          break;
                      }
                      case 'CLOSING': {
                          this.stompStatusId = 2;
                          break;
                      }
                      case 'CLOSED': {
                          this.stompStatusId = 3;
                          break;
                      }

                  }
              }
          });
  }

  public enviarMensaje(destino: string, mensaje: string) {

      const parametros: IPublishParams = {
        destination: destino,
        body: mensaje
      };
      this.stompService.publish(parametros);
  }

  public suscribir(topic): Observable<IMessage>{
    return this.stompService.watch(topic, {});
  }

}
