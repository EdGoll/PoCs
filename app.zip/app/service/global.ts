import { environment } from '../../environments/environment';

export const GLOBAL = {
  url: environment.backend.baseURL
};
