import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { GLOBAL } from './global';
import { Observable, Subject, BehaviorSubject, of } from 'rxjs';
import { SecurityVeh } from '../model/security-veh';
import { EventoIngresoSalida } from '../model/evento-ingreso-salida';
import { MensajeIntegracion } from '../model/mensaje-integracion';
import { DetalleAtencionEvento } from '../model/detalle-atencion-evento';
import { PuntoControl } from '../model/punto-control';
import { Observacion } from '../model/observacion';


@Injectable({
  providedIn: 'root'
})
/**
 * Clase del tipo service encargada de manejar peticiones rest para la salida de vehiculos
 */
export class SalidaService {

  public url: string;
  public messages: Subject<EventoIngresoSalida>;
  salidas: Observable<EventoIngresoSalida[]>;
  procesadas: Observable<EventoIngresoSalida[]>;
  private _salidas: BehaviorSubject<EventoIngresoSalida[]>;
  private _procesadas: BehaviorSubject<EventoIngresoSalida[]>;
  private dataStore: {
    salidas: EventoIngresoSalida[],
    procesadas: EventoIngresoSalida[]
  };

  constructor(private http: HttpClient, private securityVeh: SecurityVeh) {
    this.url = GLOBAL.url;
    console.log('Se inicializa servicio admision');
    this.dataStore = { salidas: [], procesadas: [] };
    this._salidas = new BehaviorSubject([]) as BehaviorSubject<EventoIngresoSalida[]>;
    this.salidas = this._salidas.asObservable();

    this._procesadas = new BehaviorSubject([]) as BehaviorSubject<EventoIngresoSalida[]>;
    this.procesadas = this._procesadas.asObservable();
  }

  // Obtiene las solicitudes otorgadas y rechazadas
  getProcesadosSalida(idPuntoControl: number, idAduana: number){

    this.http.get<EventoIngresoSalida[]>(`${this.url}/salida/procesados/`,
     {
       headers: this.securityVeh.getParametrosHeader(),
       params: this.securityVeh.getParametrosSeguridad()}).subscribe(
      data => {
        this.dataStore.procesadas = data;
        this._procesadas.next(Object.assign({}, this.dataStore).procesadas);
      },
      error => {
        console.log(error);
      }
    );


  }
  // Obtiene las solicitudes autorizadas y observadas
  getSolicitudesSalida(idPuntoControl: number, idAduana: number) {

    this.http.get<EventoIngresoSalida[]>(this.url + '/salida/ultimos',
    { headers: this.securityVeh.getParametrosHeader(),
      params: this.securityVeh.getParametrosSeguridad()} ).subscribe(
      data => {
        this.dataStore.salidas = data;
        this._salidas.next(Object.assign({}, this.dataStore).salidas);
      },
      error => {
        console.log(error);
      }
    );
  }

  getEvento(id): Observable<EventoIngresoSalida> {
    return this.http.get<EventoIngresoSalida>(this.url + '/salida/evento/' + id,
    { headers: this.securityVeh.getParametrosHeader(),
      params: this.securityVeh.getParametrosSeguridad()
    });
  }

  getListadoEventoObservacion(idEvento): Observable<Observacion[]> {
    return this.http.get<Observacion[]>(this.url + '/salida/hist/' + idEvento,
    {
      headers: this.securityVeh.getParametrosHeader(),
      params: this.securityVeh.getParametrosSeguridad()
    });
  }

  getObservacionIngresoSalida(idEvento): Observable<Observacion[]> {
    return this.http.get<Observacion[]>(this.url + '/salida/hist/' + idEvento,
    {
      headers: this.securityVeh.getParametrosHeader(),
      params: this.securityVeh.getParametrosSeguridad()
    });
  }

  loadAll(idPuntoControl: string, idAduana: number) {
    this.http.get<EventoIngresoSalida[]>(`${this.url}/salida/ultimos`,
      {
        headers: this.securityVeh.getParametrosHeader()
      }).subscribe(
      data => {
        this.dataStore.salidas = data;
        this._salidas.next(Object.assign({}, this.dataStore).salidas);
    },
    error => console.log('Could not load todos.')
    );
  }

  load(id: number | string) {
    this.http.get<EventoIngresoSalida>(`${this.url}/todos/${id}`).subscribe(data => {
      let notFound = true;

      this.dataStore.salidas.forEach((item, index) => {
        if (item.idEvento === data.idEvento) {
          this.dataStore.salidas[index] = data;
          notFound = false;
        }
      });

      if (notFound) {
        this.dataStore.salidas.push(data);
      }

      this._salidas.next(Object.assign({}, this.dataStore).salidas);
    }, error => console.log('Could not load todo.'));
  }

  create(todo: EventoIngresoSalida) {
    // this.http.post<Salida>(`${this.url}/todos`, JSON.stringify(todo)).subscribe(data => {
       this.dataStore.salidas.push(todo);
       this._salidas.next(Object.assign({}, this.dataStore).salidas);
     //}, error => console.log('Could not create todo.'));
   }

   accionEventoSalida(admision: EventoIngresoSalida, accionAdmision: string, observacion: string): Observable<any> {
    console.log('Entro a accionEventoSalida' + admision);
    let accion = {} as MensajeIntegracion;
    accion.evento = {} as EventoIngresoSalida;
    accion.evento.idEvento = admision.idEvento;
    accion.evento.detalleAtencion = {} as DetalleAtencionEvento;
    accion.evento.detalleAtencion.observacion = observacion;
    accion.tipoSolicitud = accionAdmision;
    accion.evento.puntoControl = {} as PuntoControl;
    accion.evento.puntoControl.codAduana = admision.puntoControl.codAduana;
    accion.evento.puntoControl.codPunto = admision.puntoControl.codPunto;

    return this.http.post<MensajeIntegracion>(this.url + '/salida/accion', accion, {
      headers: this.securityVeh.getParametrosHeader(),
      params: this.securityVeh.getParametrosSeguridad()
    });
  }
}
