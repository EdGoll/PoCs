import {throwError as observableThrowError,  Observable ,  BehaviorSubject } from 'rxjs';

import {take, filter, catchError, switchMap, finalize} from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpSentEvent, HttpHeaderResponse,
  HttpProgressEvent, HttpResponse, HttpUserEvent, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { SessionStorageService } from 'ngx-webstorage';


@Injectable()
export class RefreshTokenInterceptor implements HttpInterceptor {

    // Refresh Token Subject tracks the current token, or is null if no token is currently
    // available (e.g. refresh pending).
    isRefreshingToken: boolean = false;
    tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>(null);

    constructor(private injector: Injector, private loginService: LoginService,
                private router: Router, private sessionStorage: SessionStorageService) {}

    addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
      return req.clone({ setHeaders: { Authorization: 'Basic ' + btoa('my-trusted-client:secret') },
        setParams: { access_token: token}
                       });
  }

    intercept(req: HttpRequest<any>, next: HttpHandler ): Observable<HttpEvent<any>> {
      // console.log('Entro a token interceptor');

      req = req.clone({
        setHeaders: {
          Authorization: 'Basic ' + btoa('my-trusted-client:secret')
        }
      });

      return next.handle(req).pipe(
        catchError(error => {
            if (error instanceof HttpErrorResponse) {
                switch ((<HttpErrorResponse>error).status) {
                    case 400:
                        return this.handle400Error(error);
                    case 401:
                        return this.handle401Error(req, next);
                    default:
                        return observableThrowError(error);
                }
            } else {
                return observableThrowError(error);
            }
      }));
    }

    handle400Error(error) {
      // console.log('Entro a metodo handle400Error');
      if (error && error.status === 400 && error.error && error.error.error === 'invalid_grant') {
          // If we get a 400 and the error message is 'invalid_grant', the token is no longer valid so logout.
          return observableThrowError(error);
      }

      return observableThrowError(error);
    }

    handle401Error(req: HttpRequest<any>, next: HttpHandler) {
      // console.log('Entro a metodo handle401Error');
      if (!this.isRefreshingToken) {
        this.isRefreshingToken = true;

        // Reset here so that the following requests wait until the token
        // comes back from the refreshToken call.
        this.tokenSubject.next(null);

        const authService = this.injector.get(LoginService);

        return authService.refreshToken2().pipe(
            switchMap((data: any) => {
               // console.log('entra a switchMap');
               // console.log(data);
               this.isRefreshingToken = false;
               this.sessionStorage.store('access_token', JSON.parse(JSON.stringify(data)).access_token);
               this.sessionStorage.store('refresh_token', JSON.parse(JSON.stringify(data)).refresh_token);
               const newToken = JSON.parse(JSON.stringify(data)).access_token;

               if (newToken) {
                   // console.log('actualiza nuevo token:'+ newToken);
                    this.tokenSubject.next(newToken);
                    return next.handle(this.addToken(req, newToken));
                }

                // If we don't get a new token, we are in trouble so logout.
               return this.logoutUser();
            }),
            catchError(error => {
                // If there is an exception calling 'refreshToken', bad news so logout.
                console.log('Error en catchError:' + JSON.stringify(error));
                return this.logoutUser();
            }),
            finalize(() => {
               // console.log('interceptor:entro a finalize');
                this.isRefreshingToken = false;
            }));
    } else {
        // console.log('ERROR_401:entro a else' + this.isRefreshingToken);
        return this.logoutUser();
        /*
        return this.tokenSubject.pipe(
            filter(token => token != null),
            take(1),
            switchMap(token => {
              return next.handle(this.addToken(req, token));
            }));
            */
}
    }

    logoutUser() {
      // Route to the login page (implementation up to you)
      this.loginService.logout();
      this.router.navigate(['/']);
      return observableThrowError('');

  }
}
