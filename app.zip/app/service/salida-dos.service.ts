import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, Subscription } from 'rxjs';
import { GLOBAL } from './global';
import { SocketStompProvider } from './socket/socket-stomp-provider.service';
import { EventoIngresoSalida } from '../model/evento-ingreso-salida';

@Injectable({
  providedIn: 'root'
})
/**
 * Clase del tipo servicio encargada de obtener informacion de salida mediante websocket
 */
export class SalidaDosService {

  // solicitudes de salida
  salidas: Observable<EventoIngresoSalida[]>;
  private _salidas: BehaviorSubject<EventoIngresoSalida[]>;
  private topicSubscriptionSolSal: Subscription;

  // salidas procesadas
  procesadas: Observable<EventoIngresoSalida[]>;
  private _procesadas: BehaviorSubject<EventoIngresoSalida[]>;
  private topicSubscriptionSalProc: Subscription;

  public url: string;
  private dataStore: {
    salidas: EventoIngresoSalida[],
    procesadas: EventoIngresoSalida[]
  };

  constructor(private socketService: SocketStompProvider) {
    this.url = GLOBAL.url;
    this.dataStore = { salidas: [], procesadas: [] };
    this._salidas = new BehaviorSubject([]) as BehaviorSubject<EventoIngresoSalida[]>;
    this.salidas = this._salidas.asObservable();

    this._procesadas = new BehaviorSubject([]) as BehaviorSubject<EventoIngresoSalida[]>;
    this.procesadas = this._procesadas.asObservable();
  }

  /**
   * Metodo que escucha un canal websocket para la recepcion de solicitudes de salida
   */
  openWebSocketSolicitudesSalida() {
    this.topicSubscriptionSolSal = this.socketService.suscribir('/topic/message').subscribe(
      data => {
        let notFound = true;
        let salidasTemp: EventoIngresoSalida[];
        salidasTemp = JSON.parse(data.body) as EventoIngresoSalida[];

        if (notFound) {
        this.dataStore.salidas = [];
        this.dataStore.salidas = salidasTemp;
      }

        this._salidas.next(Object.assign({}, this.dataStore).salidas);
      }, error => console.log('Could not load todo.')
    );
}

/**
 * Metodo que escucha un canal websocket para la recepcion de salidas procesadas
 */
openWebSocketSalidasProcesadas() {
  this.topicSubscriptionSalProc = this.socketService.suscribir('/topic/salidaProcesada').subscribe(
    data => {
      // console.log(data);
      let notFound = true;
      let salidasTemp: EventoIngresoSalida[];
      salidasTemp = JSON.parse(data.body) as EventoIngresoSalida[];

      if (notFound) {
      this.dataStore.procesadas = [];
      this.dataStore.procesadas = salidasTemp;
    }

      this._procesadas.next(Object.assign({}, this.dataStore).procesadas);
    }, error => console.log('Could not load todo.')
  );
}

/**
 * Metodo encargado de desinscribirse de la cola /topic/message para solicitudes de salida
 */
desinscribirRecepcionSolicitudesSalida() {
  if(this.topicSubscriptionSolSal !== undefined){
    this.topicSubscriptionSolSal.unsubscribe();
  }
}

/**
 * Metodo encargado de desinscribirse de la cola /topic/message para salidas procesadas
 */
desinscribirFlujoSalidasProcesadas() {
  if(this.topicSubscriptionSalProc !== undefined){
    this.topicSubscriptionSalProc.unsubscribe();
  }
}

/*
  static getSalida(post: any): Salida {
    return {...post};
}
*/

}
