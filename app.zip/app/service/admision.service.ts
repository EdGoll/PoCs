import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse  } from '@angular/common/http';
import { GLOBAL } from './global';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { AdmisionForm } from '../model/admision-form';
import { SecurityVeh } from '../model/security-veh';
import { EventoIngresoSalida } from '../model/evento-ingreso-salida';
import { MensajeIntegracion } from '../model/mensaje-integracion';
import { DetalleAtencionEvento } from '../model/detalle-atencion-evento';
import { PuntoControl } from '../model/punto-control';

@Injectable({
  providedIn: 'root'
})

export class AdmisionService {

  public url: string;

  constructor(private http: HttpClient , private securityVeh: SecurityVeh) {
    this.url = GLOBAL.url;
    console.log('Se inicializa servicio admision');
  }

  private getHeaderParams() {
    return this.securityVeh.getParametrosHeader();
  }

  private getAuthParams() {
    return this.securityVeh.getParametrosSeguridad();
  }

  private getHttpRequestParams() {
    return {
              headers: this.getHeaderParams(),
              params: this.getAuthParams()
           };
  }

  getUltimosMovimientosAdmision() {

    return this.http.get<any>(this.url + '/admision/', this.getHttpRequestParams());

  }

  getDetalleMovimiento(id: string) {

    return this.http.get<any>(this.url + '/admision/?placa=' + id, this.getHttpRequestParams());

  }

  getEventoPorPatente(patenteInput: string) {

    return this.http.get<any>(this.url + '/consultas/patente/' + patenteInput, this.getHttpRequestParams());
  }


  agregarAdmision(form: AdmisionForm): Observable<AdmisionForm> {
    // console.log(form);
    return this.http.post<AdmisionForm>(this.url + '/admision/nueva/', form, this.getHttpRequestParams())
      .pipe(
        catchError(this.handleError)
      );

  }

  accionEventoAdmision(admision: EventoIngresoSalida, accionAdmision: string, observacion: string): Observable<any> {
    // console.log('Entro a accionEventoAdmision' + admision);
    let accion = {} as MensajeIntegracion;
    accion.evento = {} as EventoIngresoSalida;
    accion.evento.idEvento = admision.idEvento;
    accion.evento.detalleAtencion = {} as DetalleAtencionEvento;
    accion.evento.detalleAtencion.observacion = observacion;
    accion.tipoSolicitud = accionAdmision;
    accion.evento.puntoControl = {} as PuntoControl;
    accion.evento.puntoControl.codAduana = admision.puntoControl.codAduana;
    accion.evento.puntoControl.codPunto = admision.puntoControl.codPunto;

    return this.http.post<MensajeIntegracion>(this.url + '/admision/accion', accion, this.getHttpRequestParams());
  }

  private handleError(error: Response | any) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return Observable.throw(error.message || error);
  }


}
