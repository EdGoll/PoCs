import { Injectable } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from '../usuario/login/login.component';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { GLOBAL } from './global';
import { of as observableOf, Observable, of } from 'rxjs';
import {delay} from 'rxjs/operators';
import { map } from 'rxjs/operators';
import { SessionStorageService } from 'ngx-webstorage';
import { UsuarioService } from './usuario.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private isOpen = false;
  private url = null;
  public currentToken: string;

  constructor(private modalService: NgbModal,
              private http: HttpClient,
              private usuarioService: UsuarioService,
              private sessionStorage: SessionStorageService) {
    console.log('Se inicializa servicio login');
    this.url = GLOBAL.url;
  }

  /**
   * Limpia access_token,refresh_token,identity,authenticated de sessionStorage
   * Limpia authenticationToken de sessionStorage
   * Limpia variable Subject authenticationState
   */
  logout() {
    // limpiar datos del usuario
    this.cleanToken();
    this.usuarioService.logout();
    this.sessionStorage.store('isAuthenticated', 'false');
    this.sessionStorage.clear();
  }



  obtainAccessToken(username, password): Observable<any> {
    // console.log('Entro a obtainAccessToken');
    const params = new HttpParams()
    .set('username', username)
    .set('password', password)
    .set('grant_type', 'password');

    const headers = {
      Authorization: 'Basic ' + btoa('my-trusted-client:secret'),
      'Content-type': 'application/x-www-form-urlencoded'
    };

    return this.http.post(this.url + '/oauth/token', params, {headers});

  }

  refreshToken2(): Observable<any> {

    // console.log('Entro a refreshToken:');
    const params = new HttpParams()
    .set('grant_type', 'refresh_token')
    .set('refresh_token', this.sessionStorage.retrieve('refresh_token'));

    const headers = {
      Authorization: 'Basic ' + btoa('my-trusted-client:secret'),
      'Content-type': 'application/x-www-form-urlencoded'
    };

    return this.http.post(this.url + '/oauth/token', params, {headers});
}


  cleanToken() {
    this.sessionStorage.clear('access_token');
    this.sessionStorage.clear('refresh_token');
    this.sessionStorage.clear('identity');
    this.sessionStorage.clear('authenticated');
  }

  isAuthenticated(): boolean {
    if (JSON.parse(this.sessionStorage.retrieve('isAuthenticated')) == null) {
      return false;
    }
    return (this.sessionStorage.retrieve('isAuthenticated') === 'true') ? true : false;
}
}
