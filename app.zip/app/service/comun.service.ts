import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GLOBAL } from './global';
import { Observable } from 'rxjs';
import { PuntoControl } from '../model/punto-control';

@Injectable({
  providedIn: 'root'
})
export class ComunService {

  public url: string;
  constructor(
    private http: HttpClient
  ) {
    this.url = GLOBAL.url;
    // console.log('Se inicializa servicio comun');
  }

  getListadoAduanas(): Observable<PuntoControl[]> {
    return this.http.get<PuntoControl[]>(this.url + '/tipos/puntoControl');
  }


}
