import { Injectable } from '@angular/core';

import {
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivate,
  UrlTree
} from '@angular/router';
import { Observable, of, from } from 'rxjs';
import { UsuarioService } from './usuario.service';
import { NotificacionService } from '../common/notificacion.service';
import { SessionStorageService } from 'ngx-webstorage';

@Injectable({
  providedIn: 'root'
})
export class AccesoRutasUsuarioService implements CanActivate {
  constructor(private router: Router,
              private usuarioService: UsuarioService,
              private notificationsService: NotificacionService,
              private $sessionStorage: SessionStorageService) {}

  resultado: boolean;

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Promise<boolean> {
    const authorities = route.data['authorities'];
    // console.log(authorities);
    // We need to call the checkLogin / and so the accountService.identity() function, to ensure,
    // that the client has a principal too, if they already logged in by the server.
    // This could happen on a page refresh.

    return this.checkLogin(authorities, state.url);

  }

  checkLogin(authorities: string[], url: string ): Promise<boolean> {
    const username = this.$sessionStorage.retrieve('username') as string;
    return this.usuarioService.identity(username).then(account => {
      if (!authorities || authorities.length === 0) {
          return true;
      }

      if (account) {
          const hasAnyAuthority = this.usuarioService.hasAnyAuthority(authorities);
          if (hasAnyAuthority) {
              return true;
          }
          //if (isDevMode()) {
          //    console.error('User has not any of required authorities: ', authorities);
          //}
          console.log('No tiene permisos para acceder:'+ url);
          this.notificationsService.notify('warn', 'No tiene permisos', 'Acceso denegado');
          return false;
      }

      //this.stateStorageService.storeUrl(url);
      this.router.navigate(['accessdenied']).then(() => {
          // only show the login dialog, if the user hasn't logged in yet
          if (!account) {
              console.log('abriendo login modal service');
              //this.loginModalService.open();
          }
      });
      return false;
  });
  }
}
