import { Tipo } from './tipo';

export interface HistorialAtencion {
  estadoAtencion: Tipo;
  fechaInicio: string;
  fechaTermino: string;
  usuario: string;
  ip: string;
}
