import { Item } from './item';
import { Tipo } from './tipo';

export interface Vehiculo {

     pais: Item;
     placa: string;
     motor: string;
     chasis: string;
     anioFabricacion: number;
     marca: Tipo;
     tipoVehiculo: Item;
     color: Tipo;
}
