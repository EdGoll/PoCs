export interface TipoVehiculo {
  id: number;
  glosa: string;
  filtroWeb: string;
  codSrcei: string;
}
