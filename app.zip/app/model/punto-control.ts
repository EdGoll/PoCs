
export interface PuntoControl {
  codAduana: number;
  codPunto: number;
  nombrePuntoControl: string;
}
