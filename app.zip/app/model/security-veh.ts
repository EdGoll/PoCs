import { HttpParams, HttpHeaders } from '@angular/common/http';
import { SessionStorageService } from 'ngx-webstorage';
import { Injectable } from '@angular/core';
import { PuntoControl } from './punto-control';

@Injectable({
  providedIn: 'root'
})
export class SecurityVeh {

constructor(private sessionStorage: SessionStorageService){

}

getParametrosSeguridad(): HttpParams {

 const token =  this.sessionStorage.retrieve('access_token');
 const params = new HttpParams().set('access_token', token);

 return params;
 //return new HttpParams();
}

getParametrosHeader(): HttpHeaders {

  // Obtener aduana y punto de control
  const puntoControl = this.sessionStorage.retrieve('puntoControl') ;
  let idPuntoControl = null;
  let idAduana = null;
  if (puntoControl) {
    idPuntoControl = (JSON.parse(puntoControl) as PuntoControl).codPunto;
    idAduana = (JSON.parse(puntoControl) as PuntoControl).codAduana;
  }
  // Obtener el login del usuario
  const usuario = this.sessionStorage.retrieve('identity');
  let login = null;
  if (usuario) {
    login = JSON.parse(JSON.stringify(usuario)).login;
  }

  // Preparar objeto headers
  let headers = new HttpHeaders();
  headers = headers.append('Content-Type', 'application/json');
  if (idAduana) {
    headers = headers.append('aduana', idAduana);
  }
  if (idPuntoControl) {
    headers = headers.append('ptoControl', idPuntoControl);
  }
  if (login) {
      headers = headers.append('login', login);
  }

  // Se deja ip en duro
  headers = headers.append('ip', '192.168.10.125');

  return headers;
}

}
