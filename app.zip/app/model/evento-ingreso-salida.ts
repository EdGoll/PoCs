import { Persona } from './persona';
import { PuntoControl } from './punto-control';
import { Vehiculo } from './vehiculo';
import { Observacion } from './observacion';
import { Tipo } from './tipo';
import { DetalleAtencionEvento } from './detalle-atencion-evento';

export interface EventoIngresoSalida {

  idEvento: number;
  fechaEvento: string;
  tipoOperacion: string;
  numeroTitulo: string;
  numeroViaje: number;
  tipoEvento: Tipo;
  puntoControl: PuntoControl;
  vehiculo: Vehiculo;
  conductor: Persona;
  cantidadPasajeros: number;
  estadoAtencion: Tipo;
  estadoAutorizacion: Tipo;
  nivelInspeccion: Tipo;
  observaciones: Observacion[];
  detalleAtencion: DetalleAtencionEvento;
}
