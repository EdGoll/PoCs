export interface Tipo {
  id: string;
  descripcion: string;
}
