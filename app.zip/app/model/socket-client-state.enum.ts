export enum SocketClientState {
  ATTEMPTING, CONNECTED
}
