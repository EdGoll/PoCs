export interface Pais {
  paiCodigo: number;
  codigoIso2: string;
  codigoIso3: string;
  codigoIsoN: number;
}
