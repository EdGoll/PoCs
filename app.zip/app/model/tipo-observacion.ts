export interface TipoObservacion{
  idTipoObs: number;
  nombreTipoObservacion: string;
}
