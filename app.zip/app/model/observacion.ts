import { Item } from './item';

export interface Observacion {
  id: number;
  detalle: string;
  estado: Item;
  tipoObs: Item;
}
