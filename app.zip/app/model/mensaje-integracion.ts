import { EventoIngresoSalida } from './evento-ingreso-salida';

export interface MensajeIntegracion {
  tipoSolicitud: string;
  evento: EventoIngresoSalida;
}
