
import { Vehiculo } from './vehiculo';
import { Persona } from './persona';

export interface AdmisionForm {

     vehiculo: Vehiculo;
     conductor: Persona;
     cantidadPasajeros: number;

}
