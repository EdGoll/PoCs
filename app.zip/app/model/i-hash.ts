export interface IHash {
  [details: string]: string;
}
