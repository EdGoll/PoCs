export interface TipoDocumento {
  id: number;
  nombre: string;
  sigla: string;
  tipoPersona: string;
}
