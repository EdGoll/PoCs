export interface Item {
  id: number;
  descripcion: string;
}
