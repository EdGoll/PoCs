import { Pais } from './pais';
import { Item } from './item';

export interface Persona {

        nombres: string;
        primerNombre: string;
        segundoNombre: string;
        apPaterno: string;
        apMaterno: string;
        nroDocumentoIdentif: string;
        dv: string;
        tipoDoctoIdentif: Item;
        nacionalidad: Item;
        propietario: string;
        // fechaRetornoVisa: string;

}
