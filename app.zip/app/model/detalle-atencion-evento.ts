import { HistorialAtencion } from './historial-atencion';

export interface DetalleAtencionEvento {
  fechaIniAtencion: string;
  fechaFinAtencion: string;
  usuarioAutoriza: string;
  tipoAutorizacion: string;
  detalleRechazo: string;
  observacion: string; // jmayne se agrega este mensaje
  historialAtencion: HistorialAtencion[];
}
