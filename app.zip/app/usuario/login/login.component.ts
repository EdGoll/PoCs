import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginService } from 'src/app/service/login.service';
import { UsuarioService } from 'src/app/service/usuario.service';
import { PuntoControl } from 'src/app/model/punto-control';
import { ComunService } from 'src/app/service/comun.service';
import { SessionStorageService } from 'ngx-webstorage';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  authenticationError: boolean;
  password: string;
  // rememberMe: boolean;
  username: string;
  credentials: any;
  puntoControlList: PuntoControl[];
  puntoControl: PuntoControl;

  constructor(
    private router: Router,
    public activeModal: NgbActiveModal,
    private loginService: LoginService,
    private comunService: ComunService,
    private $sessionStorage: SessionStorageService,
    private usuarioService: UsuarioService,
  ) {}

  ngOnInit() {

    this.comunService.getListadoAduanas().subscribe(
      resp => {
        this.puntoControlList = resp;
      },
      error => {
        this.puntoControlList = [];
      }
    );
  }

  login() {
    if (
      this.username != null &&
      this.password != null &&
      this.puntoControl != null
    ) {
      // console.log('punto control:' + JSON.stringify(this.puntoControl));
      this.loginService
        .obtainAccessToken(this.username, this.password)
        .subscribe(
          data => {
            // console.log(data);
            this.$sessionStorage.store('isAuthenticated', 'true');
            this.$sessionStorage.store('puntoControl', JSON.stringify(this.puntoControl));
            this.$sessionStorage.store('access_token', data.access_token);
            this.$sessionStorage.store('refresh_token', data.refresh_token);
            this.$sessionStorage.store('username', this.username);
            this.usuarioService.identity(this.username, true).then(resp => {
              this.activeModal.dismiss('login success');
              $('.navbar-toggler').click();
              this.router.navigate(['']);
            });
          },
          error => {
            console.log(error);
            this.$sessionStorage.store('isAuthenticated', 'false');
            this.loginService.cleanToken();
            this.authenticationError = true;
          }
        );
    } else {
      this.$sessionStorage.store('isAuthenticated', 'false');
      this.loginService.cleanToken();
      this.authenticationError = true;
    }
    this.activeModal.dismiss('login success');
    $('.navbar-toggler').click();
    this.router.navigate(['']);
  }

  guardarPuntoControl(event) {
    // console.log(event);
  }

  cancel() {
    this.credentials = {
      username: null,
      password: null
    };
    this.authenticationError = false;
    this.activeModal.dismiss('cancel');
  }
}
