import { Component, OnInit, OnDestroy } from "@angular/core";
import { Message } from "primeng/primeng";
import { NotificacionService } from "../notificacion.service";
import { Subscription } from "rxjs";

@Component({
  selector: "app-notificacion",
  templateUrl: "./notificacion.component.html",
  styleUrls: ["./notificacion.component.css"]
})
export class NotificacionComponent implements OnInit, OnDestroy {
  msgs: Message[] = [];
  subscription: Subscription;
  isSticky = false;
  lifeTime = 10000;

  constructor(private notificationsService: NotificacionService) {}

  ngOnInit() {
    this.subscribeToNotifications();
  }
/*
  subscribeToNotifications() {
    this.subscription = this.notificationsService.notificationChange.subscribe(
      notification => {
        this.msgs = [];
        this.msgs.push(notification);
      }
    );
  }
*/
  subscribeToNotifications() {
    this.subscription = this.notificationsService.notificationChange.subscribe(
      notification => {
        let notificationObject = <NotificacionComponent>notification;
        this.isSticky = notificationObject.isSticky;
        this.lifeTime = notificationObject.lifeTime;
        this.msgs = [];
        this.msgs.push(notification);
      }
    );
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
