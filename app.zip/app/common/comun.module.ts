import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TieneAutorizacionDirective } from './directiva/tiene-autorizacion.directive';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';


@NgModule({
  declarations: [TieneAutorizacionDirective, ConfirmationDialogComponent],
  imports: [
    CommonModule,    
  ],
  exports: [TieneAutorizacionDirective]
})
export class ComunModule { }
