import { Directive, Input, ViewContainerRef, TemplateRef } from '@angular/core';
import { UsuarioService } from 'src/app/service/usuario.service';

@Directive({
  selector: '[appTieneAutorizacion]'
})
export class TieneAutorizacionDirective {

  private authorities: string[];

  constructor(private usuarioService: UsuarioService,
              private templateRef: TemplateRef<any>,
              private viewContainerRef: ViewContainerRef) { }

  @Input()
  set appTieneAutorizacion(value: string | string[]) {
    this.authorities = typeof value === 'string' ? [value] : value;
    this.updateView();
    this.usuarioService.getAuthenticationState().subscribe(identity => this.updateView());
  }

  private updateView(): void {
    const hasAnyAuthority = this.usuarioService.hasAnyAuthority(this.authorities);
    this.viewContainerRef.clear();
    if (hasAnyAuthority) {
        this.viewContainerRef.createEmbeddedView(this.templateRef);
    }
  }

}
