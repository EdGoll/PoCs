import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {NgxWebstorageModule} from 'ngx-webstorage';
import { AppRoutingModule } from './app-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import {
  faUser,
  faSort,
  faSortUp,
  faSortDown,
        faBars,
      faWrench,
      faClock,
      faSignOutAlt,
      faSignInAlt,
      faHome,
      faSearchLocation,
      faSearch,
      faUserPlus
} from '@fortawesome/free-solid-svg-icons';
import { HomeModule } from './home/home.module';
import { AdmisionModule } from './admision/admision.module';
import { SalidaModule } from './salida/salida.module';
import { UsuarioModule } from './usuario/usuario.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { RefreshTokenInterceptor } from './service/refresh-token.interceptor';
import { NotificacionComponent } from './common/notificacion/notificacion.component';
import { NotificacionService } from './common/notificacion.service';
import { GrowlModule } from 'primeng/primeng';
import { AppComponent, NavbarComponent, FooterComponent, ErrorComponent } from './layout';
import { ComunModule } from './common/comun.module';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    NotificacionComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FontAwesomeModule,
    NgbModule,
    NgxWebstorageModule.forRoot(),
    HomeModule,
    AdmisionModule,
    SalidaModule,
    UsuarioModule,
    ReactiveFormsModule,
    FormsModule,
    GrowlModule,
    ComunModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: RefreshTokenInterceptor, multi: true },
    NotificacionService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {
    //
    library.add(faUser);
    library.add(faSort);
    library.add(faSortUp);
    library.add(faSortDown);
    library.add(faBars);
    library.add(faHome);
    library.add(faWrench);
    library.add(faClock);
    library.add(faSignOutAlt);
    library.add(faSignInAlt);
    library.add(faSearchLocation);
    library.add(faSearch);
    library.add(faUserPlus);
  }
}
