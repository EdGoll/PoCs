import {
  AbstractControl,
  ValidatorFn,
  FormGroup,
  ValidationErrors
} from '@angular/forms';
import { ValidarRut } from './validar-rut';
/*
export function ValidateFormatoPatente(control: AbstractControl): { [key: string]: any } | null {
  const valid = /^\d+$/.test(control.value)
  const EXP_AUTO_VIEJO = new RegExp('[A-Z]{2}[1-9]{1}[0-9]{3}');
  const EXP_AUTO_NUEVO = new RegExp('[BCDFGHJKLPRSTVWXYZ]{4}[0-9]{2}');
  let respuesta = null;
  if (EXP_AUTO_VIEJO.test(control.value) || EXP_AUTO_NUEVO.test(control.value)) {
      respuesta = null;
    } else {
      return {invalidNumber: {valid: false, value: control.value}};
    }

}
*/
export function ValidateFormatoPatente(): ValidatorFn {
  return (group: FormGroup): ValidationErrors => {
    const EXP_AUTO_VIEJO = new RegExp('[A-Z]{2}[1-9]{1}[0-9]{3}');
    const EXP_AUTO_NUEVO = new RegExp('[BCDFGHJKLPRSTVWXYZ]{4}[0-9]{2}');
    const paisVeh = group.controls.paisVeh;
    const placa = group.controls.placaVeh;
    let resultado = false;
    // console.log('ValidateFormatoPatente:' + paisVeh.value.codigoPais);
    // console.log(placa.value);
/*
    if (paisVeh === undefined) {
      return null;
    } */
    if (paisVeh.value.codigoPais === 997) {
      if (EXP_AUTO_VIEJO.test(placa.value)) {
        resultado = true;
      }
      if (EXP_AUTO_NUEVO.test(placa.value)) {
        resultado = true;
      }
      if (resultado) {
        placa.setErrors(null);
      } else {
        placa.setErrors({ formatoPlacaInvalida: true });
      }
    }

    // placa.setErrors(null);
    return null;
  };
}

export function ValidateFormatoRut(): ValidatorFn {
  return (group: FormGroup): ValidationErrors => {
    const paisVeh = group.controls.paisConductorSelected;
    const numDoc = group.controls.numDoc;

    if (paisVeh.value.codigoPais === 997) {
      if (!ValidarRut.validate(numDoc.value)) {
        numDoc.setErrors({ formatoRutInvalido: true });
      } else {
        numDoc.setErrors(null);
      }
    }

    return null;
  };
}
